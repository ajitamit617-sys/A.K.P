---
name: Lakshya Academic Engine
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#444651'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#a73a00'
  on-secondary: '#ffffff'
  secondary-container: '#fd651e'
  on-secondary-container: '#571a00'
  tertiary: '#00311f'
  on-tertiary: '#ffffff'
  tertiary-container: '#004a31'
  on-tertiary-container: '#27c38a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb599'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-mobile: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system is engineered for ambitious students across India preparing for high-stakes milestones—from CBSE & State Board examinations (Classes 9–12) to hyper-competitive pathways like NDA, CDS, JEE, and NEET. The brand personality blends institutional discipline and national-service rigor with modern, high-octane EdTech momentum. It projects clarity, unwavering focus, and competitive grit.

The visual style merges structured corporate modernism with high-energy gamified EdTech elements. The aesthetic prioritizes immediate cognitive orientation: reducing exam fatigue through balanced density, high-contrast visual cues, and micro-rewards for daily habituation (streaks, goal targets, and live interactive milestones).

## Colors

The palette balances authoritative academic stability with intense achievement markers:

- **Primary (`#1E3A8A`)**: Deep Navy symbolizing discipline, intellect, and structured preparation. Used for primary toolbars, key navigational anchors, section titles, and high-priority states.
- **Secondary (`#EA580C`)**: High-energy Saffron / Amber representing ambition, dynamic momentum, and competitive spirit. Deployed for primary conversion actions, active practice timers, streak progress indicators, and critical revision alerts.
- **Tertiary (`#10B981`)**: Mint Emerald Green applied strictly to positive validation—correct answer reveals, accuracy rates, completed modules, and streak continuation.
- **Neutral (`#64748B` base slate)**: Provides structural calibration. Surface backgrounds utilize off-white slate (`#F8FAFC`) to minimize glare during prolonged night study, framed by pristine crisp white card surfaces (`#FFFFFF`) and hairline delineations (`#E2E8F0`).

Functional status accents include an alert crimson (`#EF4444`) reserved specifically for live sessions, time expiry, and incorrect assessment attempts.

## Typography

This design system uses **Plus Jakarta Sans** across all roles to ensure geometric balance, modern approachability, and optimal legibility on low-to-high density mobile displays. 

- **Headlines**: Set at extra-bold to bold weights with tight tracking (`-0.02em` to `-0.01em`) to create clear hierarchical separation between question statements, chapter banners, and dashboard modules.
- **Body**: Uses regular weight (`400`) calibrated with generous relative line height (`1.5` to `1.6`) to maintain effortless scanning during long problem sets and concept explanations.
- **Labels & Metrics**: Uses medium to bold weights (`600`–`700`). Countdown timers, ranking metrics, and test tags require elevated tracking for unambiguous legibility under exam time constraints.

## Layout & Spacing

Layouts follow a responsive fluid grid optimized for vertical mobile-first consumption:
- **Mobile (default, up to 640px)**: 4-column layout with 16px (`1rem`) outer margins and 12px (`0.75rem`) gutters. Content stays tightly integrated for thumb-reach accessibility.
- **Tablet / Split Screen (641px–1024px)**: 8-column layout with 24px outer margins and 16px gutters, facilitating split views (e.g., video lecture on the left, interactive question bank on the right).
- **Desktop (1025px+)**: 12-column fixed-max layout (max-width: 1200px) centered with 32px (`2rem`) margins and 24px gutters.

The vertical spatial rhythm is anchored to a strict 4px base increment (`0.25rem`). Component clusters use `space-xs` and `space-sm`, while modular structural sections (e.g., transitioning from Live Quizzes to Study Material) require `space-lg` to `space-xl` separation.

## Elevation & Depth

Visual hierarchy leverages crisp surface-container differentiation and soft ambient drop shadows, preventing visual clutter in data-dense testing environments:

- **Level 0 (Flat / Canvas)**: `#F8FAFC` base slate. Used for master screen backdrops.
- **Level 1 (Card Default)**: `#FFFFFF` surface with a 1px solid stroke in `#E2E8F0` and an ambient shadow (`box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`). Used for standard practice sets, chapter index tiles, and syllabus trackers.
- **Level 2 (Interactive & Elevated Cards)**: Elevated card state used for highlighted study sets, ongoing tests, or daily goals (`box-shadow: 0 4px 6px -1px rgba(30, 58, 138, 0.06), 0 2px 4px -2px rgba(30, 58, 138, 0.06)`).
- **Level 3 (Sticky Nav & Modals)**: Bottom floating navigation, persistent test submit bars, and bottom sheets (`box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)`).
- **Dynamic Live Elevation**: High-priority alert modules (e.g., Live NDA Mock Test) incorporate a soft, ambient secondary glow (`box-shadow: 0 0 16px -2px rgba(234, 88, 12, 0.25)`).

## Shapes

The design system employs a **Rounded** shape model (`roundedness: 2` / base `0.5rem` / `8px`):
- **Base Components (`0.5rem` / 8px)**: Input fields, dropdowns, table cells, and standard assessment option containers.
- **Large Surfaces (`1rem` / 16px - `rounded-lg`)**: Primary cards, modular sections, banner tiles, and drawer sheets.
- **Hero Containers (`1.5rem` / 24px - `rounded-xl`)**: Highlighted feature cards, promo modules, and modal containers.
- **Pill Shapes (`9999px`)**: Reserved exclusively for goal switches (e.g., 'NDA', 'Class 12', 'NEET'), streak counter chips, live broadcast indicators, and floating action buttons.

## Components

### Buttons
- **Primary Action (CTA)**: High-impact Amber/Saffron fill (`#EA580C`) with white label (`#FFFFFF`). Min height 48px on mobile for ergonomic tapping. `font-weight: 700`.
- **Secondary / Institutional**: Deep Navy fill (`#1E3A8A`) or 1.5px Navy stroke with Navy text for secondary drills, syllabus downloads, and filter triggers.
- **Ghost / Utility**: Neutral slate outline with subtle hover/press fill (`#F1F5F9`).

### Goal Selection Chips
- **Design**: Fully pill-shaped (`border-radius: 9999px`), horizontal auto-scrolling container.
- **Unselected**: Solid `#FFFFFF` background, 1px `#E2E8F0` border, `#64748B` typography.
- **Selected**: Solid Deep Navy (`#1E3A8A`) fill, crisp white typography, subtle outer drop shadow.

### Cards
- **Structure**: `#FFFFFF` background with 16px padding, 16px corner radius, and subtle border `#E2E8F0`.
- **Header**: Top-aligned badge tags (e.g., "Physics", "General Ability Test") paired with action overflows or completion percentages.

### Live Class & Streak Badges
- **Live Indicator**: Pill badge with crimson background (`#FEE2E2`), deep red text (`#DC2626`), featuring an animated pulsing red dot.
- **Streak Fire Badge**: Warm saffron tint background (`#FFEDD5`) featuring orange text (`#C2410C`) paired with a fire icon and day count to reinforce micro-habits.

### Input Fields & Question Selectors
- **Inputs**: 48px height, 8px border radius, `#F8FAFC` background with 1px `#CBD5E1` border. Shifts to `#2563EB` on active focus with an ambient ring.
- **Option Blocks (MCQs)**: Surface containers featuring explicit letter badges (A, B, C, D). On click, transition to deep blue selection or instant green/red evaluation states based on test mode.

### Progress Trackers
- Segmented linear tracks (height: 6px–8px) with `#E2E8F0` unfulfilled rail and gradient Amber-to-Green filled bar.